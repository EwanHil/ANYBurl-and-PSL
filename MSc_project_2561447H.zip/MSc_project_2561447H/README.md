# To run AnyBURL with PSL, open terminal and type bash run.sh

    Places to specify dataset:
        classes/Dataset.py
        config-apply.properties
        config-eval.properties
        config-learn.properties
        run.sh

    Places to change ANYBurl alpha values:
        classes/RuleImporter.py
        config-apply.properties
        config-eval.properties
        config-learn.properties
        run.sh

    Places to update /tmp file removal (e.g: "rm /tmp/psl_h2_ewan@fidra.mv.db")
        main.ipynb
        run.sh

# To run AnyBURL with SAFRAN, open terminal and type bash run-safran.sh

    Places to specify dataset:
        SAFRAN/AnyBURL/config-learn.properties
        SAFRAN/SAFRAN-CONFIG.txt
    Places to change ANYBurl alpha values:
        SAFRAN/AnyBURL/config-learn.properties
        SAFRAN/SAFRAN-CONFIG.txt

