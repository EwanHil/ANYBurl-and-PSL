This Version of ANYBurl is not setup to do anything more than create rules for SAFRON using the command:
java -cp AnyBURL-REX.jar de.unima.ki.anyburl.LearnReinforced config-learn.properties 