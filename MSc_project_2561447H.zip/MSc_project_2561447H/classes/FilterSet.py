import numpy as np

class FilterSet():
    def __init__(self,filter_set):
        self.filter_set = filter_set.tolist()
    
    def add_to_filter_set(self,filter_set):
        self.filter_set = self.filter_set + filter_set.tolist()