#!/bin/bash

function main() {
    trap exit SIGINT
    java -cp SAFRAN/AnyBURL/AnyBURL-REX.jar de.unima.ki.anyburl.LearnReinforced SAFRAN/AnyBURL/config-learn.properties
    SAFRAN/SAFRAN calcjacc SAFRAN/SAFRAN-CONFIG.txt
    SAFRAN/SAFRAN learnnrnoisy SAFRAN/SAFRAN-CONFIG.txt
    SAFRAN/SAFRAN applynrnoisy SAFRAN/SAFRAN-CONFIG.txt
    jupyter nbconvert --to python SAFRAN-eval.ipynb
    echo "Running SAFRAN Evaluation"
    python3 "SAFRAN-eval.py"
}

main "$@"