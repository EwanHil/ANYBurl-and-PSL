#!/bin/bash

# The run script for the python interface is very simple.
# It esentially just ensures that the data exists and runs the python script.
# User's should ensure that the `pslpython` python package is installed.

readonly BASE_NAME='main'
readonly DATASET_NAME='Nations'
readonly ALPHA='10'

function main() {
    trap exit SIGINT
    rm /tmp/psl_h2_ewan@fidra.mv.db
    rm /tmp/psl_h2_ewan@fidra.trace.db
    rm -r /tmp/psl-python
    check_requirements
    psl_preprocessing
    anyburl_learn
    psl_main
    psl_evaluation
    #anyburl_predict
    #anyburl_evaluation
}

function anyburl_learn() {
    echo "Running ANYBurl Learn"
    #Create rules
    java -cp AnyBURL.jar x.y.z.anyburl.Learn config-learn.properties 
    
    #Change file type to .txt and utf-8 encoding so we can read it in to PSL
    iconv -f UTF-8 -t ISO-8859-15 rules/alpha-${ALPHA} > rules/${DATASET_NAME}/alpha-${ALPHA}.txt
}

function anyburl_predict() {
    echo "Running ANYBurl Predict"
    java -cp AnyBURL.jar x.y.z.anyburl.Apply config-apply.properties
}

function anyburl_evaluation() {
    echo "Running ANYBurl Evaluation"
    java -cp AnyBURL.jar x.y.z.anyburl.Eval config-eval.properties
}

function psl_preprocessing() {
    jupyter nbconvert --to python preprocessing.ipynb
    echo "Running PSL Preprocessing"
    python3 "preprocessing.py"
    if [[ "$?" -ne 0 ]]; then
      echo 'ERROR: Failed to run'
      exit 60
    fi
}

function psl_main() {
    jupyter nbconvert --to python main.ipynb
    echo "Running PSL Main"
    python3 "${BASE_NAME}.py"
    if [[ "$?" -ne 0 ]]; then
      echo 'ERROR: Failed to run'
      exit 60
    fi
}

function psl_evaluation() {
    jupyter nbconvert --to python evaluation.ipynb
    echo "Running PSL Evaluation"
    python3 "evaluation.py"
    if [[ "$?" -ne 0 ]]; then
      echo 'ERROR: Failed to run'
      exit 60
    fi
}

function check_requirements() {
    type python3 > /dev/null 2> /dev/null
    if [[ "$?" -ne 0 ]]; then
      echo 'ERROR: python3 required to run project'
      exit 10
    fi
}

main "$@"
