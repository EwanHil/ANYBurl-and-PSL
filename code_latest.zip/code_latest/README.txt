Places to change dataset name:

classes/Dataset.py
config-apply.properties
config-eval.properties
config-learn.properties
run.sh

Places to change ANYBurl alpha values:

classes/RuleImporter.py
config-apply.properties
config-eval.properties
config-learn.properties
run.sh

Places to update /tmp file removal (e.g: "rm /tmp/psl_h2_ewan@fidra.mv.db")
main.ipynb
run.sh