from random import random
import math

def custom_rule_weighting(rule,weighting_type="binary", binary_threshold=0.5):
    try:
        if weighting_type.lower() == "binary": 
            rule_split = rule.split(':')
            return f"1: {rule_split[1]}" if float(rule_split[0]) > binary_threshold else  f"0: {rule_split[1]}"
        elif weighting_type.lower() == "random":
            return f"{'{:f}'.format(random())}: {rule.split(':')[1]}"
        elif weighting_type.lower() == "inverse_score":
            rule_split = rule.split(':')
            return f"{1-float(rule_split[0])}: {rule_split[1]}" 
        elif weighting_type.lower() == "inverse_log":
            rule_split = rule.split(':')
            return f"{max(0,1+math.log(float(rule_split[0])))}: {rule_split[1]}" 
        
        print("Invalid or no weighting type supplied, returning rule as is")
        return rule
    except:
        print("Invalid rule supplied, returning rule as is")
        return rule