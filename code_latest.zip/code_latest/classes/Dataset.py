from pykeen.datasets import CoDExSmall
from pykeen.datasets import Countries
from pykeen.datasets import Kinships
from pykeen.datasets import Nations
from pykeen.datasets import UMLS


#Small class so we only need to change database in one place
def get_dataset():
    return Nations()

def get_dataset_name():
    return "Nations"