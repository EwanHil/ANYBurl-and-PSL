from classes.EntityConverter import EntityConverter
import random

#Splits dataset in two
def split_dataset(dataset):
    indices = random.sample(range(len(dataset)),len(dataset))   
    split = round(len(dataset)/2)    
    return dataset[indices[:split]], dataset[indices[split:]]

#Checks for duplicates and also the length of the split datasets
def validate_dataset(dataset, dataset_1,dataset_2):
    return not any(x == True for x in (dataset_1[:, None] == dataset_2).all(-1).any(-1)) and (len(dataset_1) + len(dataset_2) == len(dataset))
    

dataset = get_dataset()
entity_converter = EntityConverter(dataset)
val_triples = dataset.validation.mapped_triples.numpy()

v_split_1, v_split_2 = split_dataset(val_triples)
validate_dataset(val_triples,v_split_1, v_split_2)