from operator import itemgetter
from tqdm import tqdm
from collections import defaultdict

def calculate_hits_at_k(rels, entity_converter,k_values=[10],):
    
    head_count = defaultdict(int)
    tail_count = defaultdict(int)
        
    for h,r,t in tqdm(rels):
        possible_heads = []
        possible_tails = []

        f = open(f"inferred-predicates/{entity_converter.relindex_to_name[r].upper()}.txt", "r",  encoding="utf-8")
        for line_no,line in enumerate(f):
            if line == []:
                continue
            line_values = line.split()
            
            #Compare inferred predicates to see if head or tails matches
            #If so, add as a possible tail or possible head for the corrupted triple respectively
            if int(line_values[0]) == h:
                possible_tails.append(line_values)              
            if int(line_values[1]) == t:  
                possible_heads.append(line_values)
                
        f.close()
        possible_heads = sorted(possible_heads, key=itemgetter(2),reverse=True)
        possible_tails = sorted(possible_tails, key=itemgetter(2),reverse=True)
        
        for k in k_values:
            #Compare possible heads and tails respectively to see if they made it in to the top K
            for pos_h,pos_t,s in possible_heads[:k]:
                if int(pos_h) == h:
                    head_count[f"{k}_head"] += 1
                    break

            for pos_h,pos_t,s in possible_tails[:k]:
                if int(pos_t) == t:
                    tail_count[f"{k}_tail"] += 1
                    break
                    
    table_headers = []           
    hits_at_k_values =[]
    
    for k in k_values:
        table_headers.append(f"hits@{k}")
        hits_at_k_values.append(round((head_count[f"{k}_head"]/len(rels) + tail_count[f"{k}_tail"]/len(rels))/2,2))
    
    output_column = ""
    output_row = ""
    for i in range(len(table_headers)):
        output_column += f"{table_headers[i]}\t"
        output_row += f"{hits_at_k_values[i]}\t"
    print(output_column)     
    print(output_row) 
        