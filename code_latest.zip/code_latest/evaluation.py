#!/usr/bin/env python
# coding: utf-8

# In[ ]:


from classes.Evaluation import calculate_hits_at_k
from classes.EntityConverter import EntityConverter
from classes.Dataset import get_dataset

dataset = get_dataset()
entity_converter = EntityConverter(dataset)
val_triples = dataset.validation.mapped_triples.numpy()

k =[1,3,10]
calculate_hits_at_k(val_triples, entity_converter,k)

