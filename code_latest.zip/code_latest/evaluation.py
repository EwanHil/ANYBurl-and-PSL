#!/usr/bin/env python
# coding: utf-8

# In[ ]:


from classes.Evaluation import calculate_hits_at_k
from classes.EntityConverter import EntityConverter
from classes.Dataset import get_dataset
from classes.FilterSet import FilterSet
import json 

f = open('params.json')
params = json.load(f)
f.close()

FILTER_RESULTS = params['PSL']['FILTER_RESULTS'] == "True"

dataset = get_dataset()
entity_converter = EntityConverter(dataset)
train_triples = dataset.training.mapped_triples.numpy()
val_triples = dataset.validation.mapped_triples.numpy()
test_triples = dataset.testing.mapped_triples.numpy()
filter_set = FilterSet(train_triples)
filter_set.add_to_filter_set(val_triples)
filter_set.add_to_filter_set(test_triples)

k =[1,3,10]
calculate_hits_at_k(test_triples, entity_converter,k, filter_set, FILTER_RESULTS)


# In[ ]:




