#!/usr/bin/env python
# coding: utf-8

# In[ ]:


# -*- coding: utf-8 -*-
"""
Created on Thu Aug  4 09:49:29 2022

@author: ewanhilton
"""

from classes.EntityConverter import EntityConverter
from classes.DatasetGenerator import generate_dataset_file
from classes.PSLFileBuilder import PSLFileBuilder
from classes.Dataset import get_dataset
from classes.Dataset import get_dataset_name

#Setting this to True is required to get all files needed for PSL,
#but is very costly
CREATE_FILES = True 

def preprocessing():
    dataset = get_dataset()
    
    train_triples = dataset.training.mapped_triples.numpy()
    val_triples = dataset.validation.mapped_triples.numpy()
    test_triples = dataset.testing.mapped_triples.numpy()   
    dataset_name = get_dataset_name()
    generate_dataset_file('train.txt',dataset_name,train_triples,dataset)
    generate_dataset_file('valid.txt',dataset_name,val_triples,dataset)
    generate_dataset_file('test.txt',dataset_name,test_triples,dataset)
    
    if CREATE_FILES:       
        train_triples = dataset.training.mapped_triples.numpy()
        val_triples = dataset.validation.mapped_triples.numpy()
        #test_triples = dataset.testing.mapped_triples.numpy()  
    
        entity_converter = EntityConverter(dataset)
        create_files(train_triples,val_triples,entity_converter)
    
    #Create files needed by PSL
def create_files(train_triples, val_triples,entity_converter):    
    filebuilder = PSLFileBuilder(train_triples, val_triples, entity_converter)
    filebuilder.build_map_files()
    filebuilder.build_obs_files()
    #filebuilder.build_target_files()
    filebuilder.build_truth_files()


# In[ ]:


preprocessing()

